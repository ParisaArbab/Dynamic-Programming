Following the steps below to compile the source codes and execute the algorithms in the project directory:

Step 1: Navigate to project directory,

Step 2: To build each [AlgorithmName].java source file run the following command:
	  javac [AlgorithmName].java
		After running the above command, you may verify the existence of a [AlgorithmName].class file in the directory by using an ls command

Step 3: To run each algorithm program, after you successfully built it's java program, run the following command and pass it sample test data as command arguments:				
		java [AlgorithmName] [arg0 [arg1..argN]]

    The program should output 3	lines of output in the same order described in the project document.


IMPORTANT!!!!
	- Source codes are developed by Java 8,
	- Execution times are in nanoseconds,
	- For each algorithm there is a java source file named [AlgorithmName].java in the project directory,
        - All source files are named in PascalCase Manner(RodCutting.java, MatrixChainMultiplication.java), 
	- In addition to algorithms java class files there is another java class file named Util.java which is used to parse command line arguments
		and prepare sample test data
	

