public class Util {
    public static int[] prepareSample(Object obj, String[] args) {
        if (args.length == 0)
        {
            if ( obj instanceof RodCutting)
                System.out.println("Oops! You MUST enter at least 1 argument representing price.");
            else if (obj instanceof MatrixChainMultiplication)
                System.out.println("Oops! You MUST enter at least 2 argument representing dimensions.");

            System.exit(0);
        }

        if (args.length == 1 && obj instanceof  MatrixChainMultiplication){
            System.out.println("Oops! You MUST enter at least 2 argument representing dimensions.");
            System.exit(0);
        }

        int[] sample = new int[args.length];

        int i = 0;
        for (String arg : args) {
            try {
                sample[i] = Integer.parseInt(arg);

                if ( sample[i] <= 0 ) {
                    System.out.printf("Oops! The %d argument is not a positive integer.", i + 1);
                    System.exit(0);
                }

                i++;
            }
            catch (NumberFormatException e) {
                System.out.printf("Oops! The %d argument is not an integer.", i + 1);
                System.exit(1);
            }
        }

        return sample;
    }
}
